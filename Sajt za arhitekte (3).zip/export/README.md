# FORRMA — export za GitHub Pages

Ovo je **jedan jedini fajl**: `index.html`. Sve je već unutra (stil, kod, slike) — nema drugih fajlova za upload, pa ne može ništa da nedostaje.

## Postavljanje na GitHub Pages
1. Napravi novi repozitorijum (ili očisti postojeći).
2. Ubaci `index.html` u root repozitorija (samo taj fajl).
3. Settings → Pages → Source: `main` grana, `/ (root)` folder.
4. Sačekaj minut-dva — sajt je na `https://<korisnik>.github.io/<repo>/`.

Fontovi i React se učitavaju sa interneta (Google Fonts, unpkg CDN), sve ostalo je lokalno u fajlu.
